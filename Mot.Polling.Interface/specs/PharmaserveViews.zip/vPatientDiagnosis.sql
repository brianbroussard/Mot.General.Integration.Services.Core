/******  VIEW DEFINITIONS FOR MEDICINE-ON-TIME DATA SHARE INTERFACE *****/
/****** Object:  View dbo.vPatientDiagnosis (5 of 12)
    Documentation Date: 02/20/03 8:37:59 AM ******/

if exists (select * from sysobjects where id = object_id('dbo.vPatientDiagnosis') and sysstat & 0xf = 2)
	drop view dbo.vPatientDiagnosis
GO

/** PROVIDES ANY AND ALL DIAGNOSIS INFO FOR EACH INDIVIDUAL PATIENT **/
/* MS SQLSERVER numeric values
		signed:
 			INTEGER = +-2,000,000,000
			SMALL INT = +- 32,767
			FLOAT = precision to 53 digits
		unsigned:
			TINY INT = 0-255
 */

CREATE VIEW dbo.vPatientDiagnosis
AS

SELECT
	--                 NOTES													FType					FLen
	mc.Patient_ID, -- not null												Integer 				  			INDEX not unique
	mc.condition_description, -- not null							VarChar					25
	c.description as Severity, -- not null						VarChar					80
	mc.onset_date, -- not null												DateTime								stored as mm/dd/yyyy hh:mm:ss
	mc.cessation_date -- nullable											DateTime								ditto
FROM	medical_condition mc,
	Code c
WHERE
	MedicalConditionTable
	[Join] CodeTable
GO