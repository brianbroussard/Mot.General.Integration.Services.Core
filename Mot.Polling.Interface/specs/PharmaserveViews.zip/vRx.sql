/******  VIEW DEFINITIONS FOR MEDICINE-ON-TIME DATA SHARE INTERFACE *****/
/******  PROVIDES A SINGLE RECORD FOR EACH RX  *****/
/****** Object:  View dbo.vRx (10 of 12)
    Documentation Date: 02/20/03 8:37:59 AM ******/

if exists (select * from sysobjects where id = object_id('dbo.vRx') and sysstat & 0xf = 2)
	drop view dbo.vRx
GO

/** PROVIDES INFO FOR EACH INDIVIDUAL RX **/

/* MS SQLSERVER numeric values
		signed:
 			INTEGER = +-2,000,000,000
			SMALL INT = +- 32,767
			FLOAT = precision to 53 digits
		unsigned:
			TINY INT = 0-255
 */

CREATE VIEW dbo.vRx
AS

SELECT
	--                 NOTES													FType					FLen
	rx.Patient_ID, -- not null												Integer									INDEX not unique
	rx.Rx_ID,	-- not null (unique ID) 								Integer									INDEX UNIQUE
	rx.External_Rx_ID, -- nullable (Rx# seen by user)	Integer 								INDEX not unique
	rx.Prescriber_ID,	-- not null (match vprescriber)	Integer 								INDEX not unique
	rx.Dosage_Signa_Code, -- nullable (T,T2,C, etc)		VarChar					 7
	s.Signa_Message AS 'Decoded_Dosage_Signa',
		-- nullable (Take 1 Teaspoonful, etc.)					VarChar				 255
	s.Signa_String, -- nullable												VarChar					80
	s.Instruction_Signa_Text, -- nullable							VarChar				 255
	rx.Date_Written, -- not null											DateTime								stored as mm/dd/yyyy hh:mm:ss
	rx.Dispense_Date, -- not null											DateTime								ditto
	d.Last_Dispense_Stop_Date, -- not null						DateTime								ditto storage - INDEX not unique
	rx.Total_Refills_Authorized, -- not null					Integer
	rx.Total_Refills_Used, -- not null								Integer
	rx.Dispensed_Item_ID, -- not null (match to vitem)Integer 				 				if dispensed_item_id
	rx.Item_Version AS 'Dispensed_Item_Version',
		-- not null																			Small Int				  				and dispensed_item_version
	i.NDC_Code, -- nullable														Char						11
	d.Quantity_Dispensed, -- nullable									Float                    2 decimals
	rx.Written_For_Item_ID, -- not null								Integer										<> written_for_itemID (INDEX not unique)
	rx.Written_For_Item_Version,-- not null						Small Int									 and writen_for_Itemversion, (INDEX not unique)
			--																																			 then it's a substitute/generic item
	rx.Script_Status, -- not null (A[ctive],P[rofile])Char						 1
	rx.Prescription_Expiration_Date, -- not null			DateTime								stored as mm/dd/yyyy hh:mm:ss
	rx.Responsible_Prescriber_ID, -- nullable					Integer
		-- if not null, match to prescriber_id
	rx.Discontinue_Date, -- nullable									DateTime								ditto stored; INDEX not unique
	rx.Quantity_Written, -- not null									Float                   trim to 2 decimals
	rx.Total_Qty_Used, -- nullable										Float                   trim to 2 decimals
	rx.Total_Qty_Authorized, -- not null							Float                   trim to 2 decimals
	rx.Days_Supply_Written, -- not null								Small Int
	rx.Days_Supply_Remaining, -- not null							Small Int
	rx.Script_Origin_Indicator,-- not null (PHO,WRI)	Char						 3
	rx.Dispense_ID,     --- not null									Integer
	rx.Last_Dispense_Number,   ---- not null					Integer
	rx.Timestamp AS 'MSSQLTS' -- not null 						SEE DISCUSSION VPATIENT				INDEX UNIQUE or not
FROM	RxTable,
	DispenseHistoryTable d,
	StringSigLookup s,
	ItemTable i
WHERE	[SigJoin] and
	[DispenseHistoryTableJoin] and [ItemTableJoin]

GO