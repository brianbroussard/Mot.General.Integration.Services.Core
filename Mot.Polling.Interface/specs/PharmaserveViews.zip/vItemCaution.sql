/******  VIEW DEFINITIONS FOR MEDICINE-ON-TIME DATA SHARE INTERFACE *****/
/****** Object:  View dbo.vItemCaution (2 of 12)
    Documentation Date: 02/20/03 8:37:59 AM ******/

if exists (select * from sysobjects where id = object_id('dbo.vItemCaution') and sysstat & 0xf = 2)
	drop view dbo.vItemCaution
GO

/** PROVIDES ALL CAUTIONS THAT MAY EXIST FOR EACH INDIVIDUAL DRUG ITEM **/
/* MS SQLSERVER numeric values
		signed:
 			INTEGER = +-2,000,000,000
			SMALL INT = +- 32,767
			FLOAT = precision to 53 digits
		unsigned:
			TINY INT = 0-255
 */

CREATE VIEW dbo.vItemCaution
AS

SELECT
--                 NOTES											FType					FLen
	ic.Item_ID,-- not null (unique ID)					Integer 				  						INDEX UNIQUE
	ic.Caution_Code, -- not null								Char						 4
	ic.Caution_Message -- not null							VarChar				 255

FROM	Item_CautionsTable ic

GO