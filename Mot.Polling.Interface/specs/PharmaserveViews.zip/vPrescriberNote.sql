/******  VIEW DEFINITIONS FOR MEDICINE-ON-TIME DATA SHARE INTERFACE *****/
/****** Object:  View dbo.vPrescriberNote (8 of 12)
    Documentation Date: 02/20/03 8:37:59 AM ******/

if exists (select * from sysobjects where id = object_id('dbo.vPrescriberNote') and sysstat & 0xf = 2)
	drop view dbo.vPrescriberNote
GO
/** PROVIDES ANY AND ALL NOTES FOR EACH INDIVIDUAL PRESCRIBER **/
/* MS SQLSERVER numeric values
		signed:
 			INTEGER = +-2,000,000,000
			SMALL INT = +- 32,767
			FLOAT = precision to 53 digits
		unsigned:
			TINY INT = 0-255
 */

CREATE VIEW dbo.vPrescriberNote
AS

SELECT
	--                 NOTES												FType					FLen
	n.Prescriber_ID,-- not null											Integer 				  				INDEX unique prescriber_id +
	n.Note_ID, -- not null													Integert				  				  note_id
	n.Note_Type_Code, -- not null										VarChar					10
	n.Create_User, -- not null											VarChar					30
	n.Create_Date, -- not null											DateTime									stored as mm/dd/yyyy hh:mm:ss
	n.Note_Text -- not null													Char						16
FROM 	Note n

GO