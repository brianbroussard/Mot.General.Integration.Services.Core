/******  VIEW DEFINITIONS FOR MEDICINE-ON-TIME DATA SHARE INTERFACE *****/
/***** provides any and all notes for a given rx ***** /
/****** Object:  View dbo.vRxNote (11 of 12)
    Documentation Date: 02/20/03 8:37:59 AM ******/

if exists (select * from sysobjects where id = object_id('dbo.vRxNote') and sysstat & 0xf = 2)
	drop view dbo.vRxNote
GO

/** PROVIDES ANY AND ALL NOTES FOR EACH INDIVIDUAL RX **/

/* MS SQLSERVER numeric values
		signed:
 			INTEGER = +-2,000,000,000
			SMALL INT = +- 32,767
			FLOAT = precision to 53 digits
		unsigned:
			TINY INT = 0-255
 */

CREATE VIEW dbo.vRxNote
AS

SELECT
	--                 NOTES													FType					FLen
	n.Rx_ID, -- not null 															Integer									INDEX UNIQUE rx_id + note_id
	n.Note_ID, -- not null (unique ID)								Integer
	n.Note_Type_Code,-- not null (GEN, etc)						VarChar					10
	n.Create_User, -- not null												VarChar					30
	n.Create_Date, -- not null												DateTime								stored as mm/dd/yyyy hh:mm:ss
	n.Note_Text -- not null														Char						16
FROM	RxNotes n

GO