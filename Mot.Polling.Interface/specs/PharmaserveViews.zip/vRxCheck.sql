/******  VIEW DEFINITIONS FOR MEDICINE-ON-TIME DATA SHARE INTERFACE *****/
/****** Object:  View dbo.vRxCheck (12 of 12)
        provides a single record for any rx changed since last noted timestamp
        Documentation Date: 02/20/03 8:37:59 AM ******/

if exists (select * from sysobjects where id = object_id('dbo.vRxCheck') and sysstat & 0xf = 2)
	drop view dbo.vRxCheck
GO


/* MS SQLSERVER numeric values
		signed:
 			INTEGER = +-2,000,000,000
			SMALL INT = +- 32,767
			FLOAT = precision to 53 digits
		unsigned:
			TINY INT = 0-255
 */

CREATE VIEW dbo.vRxCheck
AS

SELECT
	--                 NOTES													FType					FLen
	rx.Patient_ID, -- not null 											Integer 	     INDEX not unique
	rx.Rx_id,  -- not null                          Integer        INDEX UNIQUE
	rx.Dispense_date, -- not null										DateTime
	rx.timestamp as MSSQLTS, -- not null			 			Char(18)	     INDEX
	rx.dispensed_item_id, -- not null               Integer
	rx.dispensed_item_version, -- not null          SmallInt
	rx.written_for_item_id,  -- not null            Integer
	rx.written_for_item_version,  -- not null       SmallInt
	rx.prescriber_id,  -- not null                  Integer
	rx.dispense_id ---  not null                    Integer

	FROM rx

	-- and whatever other tables See Vrx for more detail on specific fields
	-- this view used for the frequent checks for changes from MOT side
	--