/******  VIEW DEFINITIONS FOR MEDICINE-ON-TIME DATA SHARE INTERFACE *****/
/****** Object:  View dbo.vPatientNote (6 of 12)
    Documentation Date: 02/20/03 8:37:59 AM ******/

if exists (select * from sysobjects where id = object_id('dbo.vPatientNote') and sysstat & 0xf = 2)
	drop view dbo.vPatientNote
GO

/** PROVIDES ANY AND ALL NOTES FOR EACH INDIVIDUAL PATIENT **/
/* MS SQLSERVER numeric values
		signed:
 			INTEGER = +-2,000,000,000
			SMALL INT = +- 32,767
			FLOAT = precision to 53 digits
		unsigned:
			TINY INT = 0-255
 */

CREATE VIEW dbo.vPatientNote
AS

SELECT
	--                 NOTES													FType					FLen
	n.Patient_ID, -- not null													Integer 				  			INDEX UNIQUE Patient_id +
	n.Note_ID, -- not null														Integer 				  			  note_id
	n.Note_Type_Code, -- not null											VarChar					10
	n.Create_User, -- not null												VarChar					30
	n.Create_Date, -- not null												DateTime								stored as mm/dd/yyyy hh:mm:ss
	n.Note_Text -- not null														Char						16
FROM	PatientNoteTable n

GO