/******  VIEW DEFINITIONS FOR MEDICINE-ON-TIME DATA SHARE INTERFACE *****/
/****** Object:  View dbo.vPatientAllergy (4 of 12)
    Documentation Date: 02/20/03 8:37:59 AM ******/

if exists (select * from sysobjects where id = object_id('dbo.vPatientAllergy') and sysstat & 0xf = 2)
	drop view dbo.vPatientAllergy
GO

/** PROVIDES ANY AND ALL ALLERGY INFO FOR EACH INDIVIDUAL PATIENT **/
/* MS SQLSERVER numeric values
		signed:
 			INTEGER = +-2,000,000,000
			SMALL INT = +- 32,767
			FLOAT = precision to 53 digits
		unsigned:
			TINY INT = 0-255
 */

CREATE VIEW dbo.vPatientAllergy
AS

SELECT
	--                 NOTES													FType					FLen
	pa.Patient_ID, -- not null match to p.patient_id	Integer 				  			INDEX UNIQUE patient_id +
	pa.Patient_Allergy_ID, -- not null 								Integer 				          allergy_id
	pa.Allergy_Class_Code, -- nullable								VarChar					 3
	pa.Description, -- nullable												VarChar					80
	pa.Allergy_Free_Text, -- nullable									VarChar					30
	pa.Item_ID, -- nullable 													Integer
		-- (if not null, matches to vitem.item_id)
	pa.Onset_Date -- not null													DateTime								stored as mm/dd/yyyy hh:mm:ss

FROM	Patient_AllergyTable pa

GO