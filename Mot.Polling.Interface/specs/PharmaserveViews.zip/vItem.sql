/******  VIEW DEFINITIONS FOR MEDICINE-ON-TIME DATA SHARE INTERFACE *****/
/****** Object:  View dbo.vItem (1 of 12)
    Documentation Date: 02/20/03 8:37:59 AM ******/

if exists (select * from sysobjects where id = object_id('dbo.vItem') and sysstat & 0xf = 2)
	drop view dbo.vItem
GO

/** PROVIDES SIG & OTHER INFO ON EACH INDIVIDUAL DRUG ITEM **/
/* MS SQLSERVER numeric values
		signed:
 			INTEGER = +-2,000,000,000
			SMALL INT = +- 32,767
			FLOAT = precision to 53 digits
		unsigned:
			TINY INT = 0-255
 */

CREATE VIEW dbo.vItem
AS

SELECT
--                 NOTES											FType					FLen
	i.ITEM_ID,       --	unique ID w/version			Integer 			  							INDEX UNIQUE Item_id + item_version
	i.ITEM_VERSION,  -- unique ID w/item        Small Int
	i.NDC_CODE,      -- nullable								Char					11							INDEX not unique
	i.PACKAGE_CODE,  -- not null								Char					 2
	i.PACKAGE_SIZE,  -- nullable								Float
	i.CURRENT_ITEM_VERSION,-- ditto item_version
	i.ITEM_TYPE,    -- not null (DRG, OTC) 			Char					 3
	i.ITEM_NAME,    -- not null									VarChar				40							INDEX not unique
	i.KDC_NUMBER,   -- not null									Integer
	i.GPI_GROUP_CODE,-- not null								Tiny int
	i.GPI_CLASS_CODE,-- not null    						Tiny int
	i.GPI_SUBCLASS_CODE,-- not null							Tiny int
	i.GPI_NAME_CODE, -- not null								Tiny int
	i.GPI_NAME_EXTENSION_CODE, -- not null			Tiny int
	i.GPI_DOSAGE_FORM_CODE, -- not null					Tiny int
	i.GPI_STRENGTH_CODE, -- not null						Tiny int
	i.HRI_NUMBER, -- nullable										VarChar				13
	s.DOSAGE_SIGNA_CODE, -- nullable						VarChar 			 7
	s.INSTRUCTION_SIGNA_STRING, -- nullable			VarChar				80
	i.FORM_TYPE, -- not null (T, C, etc)				Char					 4
	i.ROUTE_OF_ADMINISTRATION, -- nullable			Char					 3
	i.ALTERNATE_MANUFACTURER_ID,-- nullable			Integer
	i.UPC, -- nullable													VarChar				13
	i.STRENGTH, -- nullable											VarChar				15
	i.COLOR_CODE, -- nullable										VarChar				 4
	i.FLAVOR_CODE, -- nullable									VarChar				 4
	i.SHAPE_CODE, -- nullable										VarChar				 4
	i.PRODUCT_MARKING, -- nullable							VarChar				10
	i.NARCOTIC_CODE, -- nullable								Char					 1
	i.UNIT_SIZE, -- nullable										Float
	i.UNIT_OF_MEASURE, -- nullable							Char					 2
	m.NDC_Manufacturer_Number, -- nullable			Char					 5
	m.Manufacturer_Abbreviation -- nullable			VarChar				10

FROM ItemTable i,
		ManufacturerTable m,
		StringSigLookup s
WHERE [ManufacturerJoin] AND
			[SigJoin]

GO