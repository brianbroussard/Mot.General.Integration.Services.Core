/****** Object:  View dbo.vPrescriberTelephone    Script Date: 10/21/02 8:37:59 AM ******/
/******  VIEW DEFINITIONS FOR MEDICINE-ON-TIME DATA SHARE INTERFACE *****/
/****** Object:  View dbo.vPrescriberTelephone (9 of 12)
    Documentation Date: 02/20/03 8:37:59 AM ******/

if exists (select * from sysobjects where id = object_id('dbo.vPrescriberTelephone') and sysstat & 0xf = 2)
	drop view dbo.vPrescriberTelephone
GO

/** PROVIDES ANY AND ALL TELEPHONE #s FOR EACH INDIVIDUAL PRESCRIBER **/
/* MS SQLSERVER numeric values
		signed:
 			INTEGER = +-2,000,000,000
			SMALL INT = +- 32,767
			FLOAT = precision to 53 digits
		unsigned:
			TINY INT = 0-255
 */

CREATE VIEW dbo.vPrescriberTelephone
AS

SELECT
	--                 NOTES												FType					FLen
	pt.Prescriber_ID,-- not null										Integer 									INDEX unique prescriber_ID+Telephone_ID
	pt.Primary_Flag, -- not null (Y, N)							Char           	 1
	pt.Telephone_ID, -- not null										Integer 									 (part 2 of unique index)
	pt.Telephone_Type, -- not null (DAYT,EVEN,FAX)	Char    				 4
	pt.Area_Code, -- nullable												Integer
	pt.Telephone_Number, -- nullable								Integer
	pt.Extension -- nullable												Integer
FROM 	Prescriber_Telephone pt

GO